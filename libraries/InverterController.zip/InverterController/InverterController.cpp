#include "InverterController.h"

InverterController::InverterController()
{
}