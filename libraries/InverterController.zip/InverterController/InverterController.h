#include <WProgram.h>

class InverterController
{
	InverterController() { }
	
	
}
